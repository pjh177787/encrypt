#include "scramble.h"

int main() {
    // Define the dimensions
    const uint8_t block_size[3] = {2, 2, 3};

    // Declare arrays
    uint8_t X[480][640][3];
    uint8_t X_after[480][640][3];
    uint8_t X_out[480][640][3];
    uint8_t key[12];

    // Read X from X.txt
    std::ifstream x_file("X.txt");
    if (!x_file) {
        std::cerr << "Error: Cannot open X.txt" << std::endl;
        return 1;
    }
    for (int i = 0; i < HEIGHT; ++i) {
        for (int y = 0; y < WIDTH; ++y) {
            for (int k = 0; k < CHANNELS; ++k) {
                int value;
                if (!(x_file >> value)) {
                    std::cerr << "Error: Not enough data in X.txt" << std::endl;
                    return 1;
                }
                X[i][y][k] = static_cast<uint8_t>(value);
            }
        }
    }
    x_file.close();

    // Read key from key.txt
    std::ifstream key_file("key.txt");
    if (!key_file) {
        std::cerr << "Error: Cannot open key.txt" << std::endl;
        return 1;
    }
    for (int i = 0; i < 12; ++i) {
        int value;
        if (!(key_file >> value)) {
            std::cerr << "Error: Not enough data in key.txt" << std::endl;
            return 1;
        }
        key[i] = static_cast<uint8_t>(value);
    }
    key_file.close();

    // Read X_after from X_after.txt
    std::ifstream x_after_file("X_after.txt");
    if (!x_after_file) {
        std::cerr << "Error: Cannot open X_after.txt" << std::endl;
        return 1;
    }
    for (int i = 0; i < HEIGHT; ++i) {
        for (int y = 0; y < WIDTH; ++y) {
            for (int k = 0; k < CHANNELS; ++k) {
                int value;
                if (!(x_after_file >> value)) {
                    std::cerr << "Error: Not enough data in X_after.txt" << std::endl;
                    return 1;
                }
                X_after[i][y][k] = static_cast<uint8_t>(value);
            }
        }
    }
    x_after_file.close();

    // Call the scramble function
    try {
        scramble(X, X_out);
    } catch (const std::exception& e) {
        std::cerr << "Error during scrambling: " << e.what() << std::endl;
        return 1;
    }

    // Compare X and X_after
    bool identical = true;
    for (int i = 0; i < HEIGHT; ++i) {
        for (int y = 0; y < WIDTH; ++y) {
            for (int k = 0; k < CHANNELS; ++k) {
                if (X_out[i][y][k] != X_after[i][y][k]) {
                    identical = false;
                    std::cout << "Difference at position [" << i << "][" << y << "][" << k << "]: "
                              << "X = " << static_cast<int>(X_out[i][y][k]) << ", "
                              << "X_after = " << static_cast<int>(X_after[i][y][k]) << std::endl;
                    // You can uncomment the next line to stop after the first difference
                    // return 1;
                }
            }
        }
    }

    if (identical) {
        std::cout << "The scrambled X matches X_after.txt. The scramble function works correctly." << std::endl;
    } else {
        std::cout << "The scrambled X does not match X_after.txt." << std::endl;
    }

    return 0;
}
