#ifndef SCRAMBLE_H
#define SCRAMBLE_H

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>

#define HEIGHT 224
#define WIDTH 224
#define CHANNELS 3

#define BLK_0 2
#define BLK_1 2
#define BLK_2 3

const int KEY[12] = {5, 4, 0, 8, 2, 10, 9, 7, 6, 1, 3, 11};

const int PADDED_HEIGHT = HEIGHT % BLK_0 + HEIGHT;
const int PADDED_WIDTH = WIDTH % BLK_1 + WIDTH;

const int max_padded_height = HEIGHT + BLK_0;
const int max_padded_width = WIDTH + BLK_1;

const int numBlockH = PADDED_HEIGHT / BLK_0;
const int numBlockW = PADDED_WIDTH / BLK_1;

void scramble(
    uint8_t X[HEIGHT][WIDTH][CHANNELS], 
    uint8_t X_out[HEIGHT][WIDTH][CHANNELS]);

#endif // SCRAMBLE_H