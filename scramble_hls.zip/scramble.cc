#include "scramble.h"

void flatten(
    uint8_t X_padded[max_padded_height][max_padded_width][CHANNELS],
    uint8_t block[12],
    int nb_h, int nb_w) {
    int idx = 0;
    for (int bh = 0; bh < BLK_0; ++bh) {
#pragma HLS UNROLL
        for (int bw = 0; bw < BLK_1; ++bw) {
#pragma HLS UNROLL
            for (int c = 0; c < CHANNELS; ++c) {
#pragma HLS UNROLL
                int h_idx = nb_h * BLK_0 + bh;
                int w_idx = nb_w * BLK_1 + bw;
                block[idx++] = X_padded[h_idx][w_idx][c];
            }
        }
    }
}

void scramble_block(
    uint8_t block[12],
    uint8_t scrambled_block[12]) {
    for (int i = 0; i < 12; ++i) {
#pragma HLS UNROLL
        scrambled_block[i] = block[KEY[i]];
    }
}

void unflatten(
    uint8_t X_padded[max_padded_height][max_padded_width][CHANNELS],
    uint8_t scrambled_block[12],
    int nb_h, int nb_w) {
    int idx = 0;
    for (int bh = 0; bh < BLK_0; ++bh) {
#pragma HLS UNROLL
        for (int bw = 0; bw < BLK_1; ++bw) {
#pragma HLS UNROLL
            for (int c = 0; c < CHANNELS; ++c) {
#pragma HLS UNROLL
                int h_idx = nb_h * BLK_0 + bh;
                int w_idx = nb_w * BLK_1 + bw;
                X_padded[h_idx][w_idx][c] = scrambled_block[idx++];
            }
        }
    }
}

void scramble(
    uint8_t X[480][640][3],
    uint8_t X_out[480][640][3]) {
#pragma HLS INTERFACE mode=m_axi port=X
#pragma HLS INTERFACE mode=m_axi port=X_out
#pragma HLS INTERFACE mode=s_axilite port=return

    uint8_t X_padded[max_padded_height][max_padded_width][CHANNELS];
#pragma HLS ARRAY_PARTITION variable = X_padded type = cyclic dim = 1 factor = BLK_2
#pragma HLS ARRAY_PARTITION variable = X_padded type = cyclic dim = 2 factor = BLK_1
#pragma HLS ARRAY_PARTITION variable = X_padded type = complete dim = 3

read_x_h:
    for (int h = 0; h < HEIGHT; ++h) {
    read_x_w:
        for (int w = 0; w < WIDTH; ++w) {
        read_x_c:
            for (int c = 0; c < CHANNELS; ++c) {
#pragma HLS PIPELINE II = 1
                X_padded[h][w][c] = X[h][w][c];
            }
        }
    }

//    for (int h = HEIGHT; h < PADDED_HEIGHT; ++h) {
//        for (int w = 0; w < WIDTH; ++w) {
//            for (int c = 0; c < CHANNELS; ++c) {
// #pragma HLS PIPELINE II = 1
//                X_padded[h][w][c] = X[HEIGHT - 1][w][c];
//            }
//        }
//    }
//
//    for (int h = 0; h < PADDED_HEIGHT; ++h) {
//        for (int w = WIDTH; w < PADDED_WIDTH; ++w) {
//            for (int c = 0; c < CHANNELS; ++c) {
// #pragma HLS PIPELINE II = 1
//                X_padded[h][w][c] = X_padded[h][WIDTH - 1][c];
//            }
//        }
//    }
scramble_h:
    for (int nb_h = 0; nb_h < numBlockH; ++nb_h) {
    scramble_w:
        for (int nb_w = 0; nb_w < numBlockW; ++nb_w) {

#pragma HLS PIPELINE II = 1

            uint8_t block[12] = {0};
#pragma HLS ARRAY_PARTITION variable = block type = complete dim = 0
            uint8_t scrambled_block[12] = {0};
#pragma HLS ARRAY_PARTITION variable = block type = complete dim = 0

            flatten(X_padded, block, nb_h, nb_w);
            scramble_block(block, scrambled_block);
            unflatten(X_padded, scrambled_block, nb_h, nb_w);
        }
    }

write_x_h:
    for (int h = 0; h < HEIGHT; ++h) {
    write_x_w:
        for (int w = 0; w < WIDTH; ++w) {
        write_x_c:
            for (int c = 0; c < CHANNELS; ++c) {
#pragma HLS PIPELINE II = 1
                X_out[h][w][c] = X_padded[h][w][c];
            }
        }
    }
}
